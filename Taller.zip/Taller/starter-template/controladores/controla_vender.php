<?php
$cantidad = $_POST["cantidad"];
if ($cantidad > 0)
{

  //aqui si mayor a 0
echo "Su compra se ha realizado con exito";
}else


{
  //aqui si es menor a 0
echo "No se pudo realizar su compra intente de nuevo";
}
?>