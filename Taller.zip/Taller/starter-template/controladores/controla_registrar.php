<?php
$edad = $_POST["edad"];
if ($edad>=18)
{

  //aqui si es mayor de 18
echo "Ha quedado registrado en el sistema";
}else


{
  //aqui si no es mayor de 18
echo "No puedes registrarte pq eres menor de edad, vuelve cuando tengas 18 años";
}
?>