<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Starter Template - Materialize</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="../css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
  <nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="#" class="brand-logo">Vender</a>
      
    <?php require_once "menu.php" ?>
      
    
     <form method = "post" action="../controladores/controla_vender.php">
      <input type="text" class="form-control" name="producto" placeholder="digite su producto a vender" required><br>
      <input type="number" class="form-control" name="cantidad" placeholder="digite la cantidad de productos a vender" required><br>
      <input type="submit" class="form-control" value="vender">
    </form>