<ul class="right hide-on-med-and-down">
        <li><a href="registrar.php">Registrar</a></li>
      </ul>
      <ul class="right hide-on-med-and-down">
        <li><a href="vender.php">Vender</a></li>
      </ul>
      <ul class="right hide-on-med-and-down">
        <li><a href="comprar.php">Comprar</a></li>
      </ul>
      